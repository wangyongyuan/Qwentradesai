"""
QwenTradeAI - AI驱动的量化交易系统
"""

__version__ = "2.0.0"

